Open the terminal and type
        " java -jar ./Senate-bus-at-Wellesley.jar "


Enter the scale as 1 for quick execution. Or for the real problem enter 100. Can choose any scale in between.

In real problem,
    mean time gap between two buses : 20 minutes
    mean time gap between two riders : 30 Seconds
